package com.myorg;

public enum Department {
	RND,HR,SALES,FINANCE,PRODUCTION
}
