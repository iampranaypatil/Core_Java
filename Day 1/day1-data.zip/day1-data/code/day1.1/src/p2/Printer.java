package p2;

public interface Printer {
//data member : public static final
	int SPEED=50;
	//methods : public abstract
	void print(String message);
	
}
