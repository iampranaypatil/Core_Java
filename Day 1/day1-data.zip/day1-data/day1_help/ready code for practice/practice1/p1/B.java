package p1;
class B extends A
{
   B()
   {
      System.out.println("B's state "+i+" "+j+" "+k+" "+l);
   }
}