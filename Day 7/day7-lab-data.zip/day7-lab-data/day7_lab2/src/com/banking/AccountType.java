package com.banking;

public enum AccountType {
	SAVING, CURRENT, FD
}
