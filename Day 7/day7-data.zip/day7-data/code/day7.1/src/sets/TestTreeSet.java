package sets;

import java.util.TreeSet;

public class TestTreeSet {

	public static void main(String[] args) {
		//LinkedHashSet() : size 0
		TreeSet<String> hs=new TreeSet<>();
		String[] names= {"Shubham","Riya","Meera","Rama","Amish","Aniket","Rupa","Riya"};
		//populate the HS with names
		for(String s : names)
			System.out.println("Added "+hs.add(s));
		//display set : toString , Iterator,for-each
		System.out.println("HS contents "+hs);
		
			

	}

}
