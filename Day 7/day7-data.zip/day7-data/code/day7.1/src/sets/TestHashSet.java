package sets;

import java.util.HashSet;

public class TestHashSet {

	public static void main(String[] args) {
		//HashSet() : size 0
		HashSet<String> hs=new HashSet<>();
		String[] names= {"Shubham","Riya","Meera","Rama","Amish","Aniket","Rupa","Riya"};
		//populate the HS with names
		for(String s : names)
			System.out.println("Added "+hs.add(s));
		//display set : toString , Iterator,for-each
		System.out.println("HS contents "+hs);
		System.out.println("HS contains "+hs.contains("Rama"));//true
		System.out.println("Removed "+hs.remove("Rama"));//true
		System.out.println("HS contains "+hs.contains("Rama"));//f
		System.out.println("HS contents again "+hs);
			

	}

}
