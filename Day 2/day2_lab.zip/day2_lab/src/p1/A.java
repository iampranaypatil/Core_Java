package p1;

public interface A {
	int DATA=100;
	void show();
}
