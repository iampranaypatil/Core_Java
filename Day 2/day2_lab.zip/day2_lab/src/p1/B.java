package p1;

public interface B {
	int DATA=200;
	void show();
}
