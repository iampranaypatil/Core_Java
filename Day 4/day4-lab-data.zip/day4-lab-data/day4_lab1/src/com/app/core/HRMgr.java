package com.app.core;

public class HRMgr extends Mgr {

	@Override
	public double computeSalary() {
		// TODO Auto-generated method stub
		return 2000;
	}

}
