package com.app.core;

public class SalesMgr extends Mgr {

	@Override
	public double computeSalary() {
		// TODO Auto-generated method stub
		return 1000;
	}

}
