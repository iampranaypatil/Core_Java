package com.app.core;

public abstract class Mgr extends Emp {
}
