package com.app.core;

public class TempWorker extends Worker {

	@Override
	public double computeSalary() {
		// TODO Auto-generated method stub
		return 500;
	}

}
