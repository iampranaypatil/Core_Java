package com.app.core;

public abstract class Worker extends Emp {
}
