package com.app.core;

public abstract class Emp /* extends Object */{
	public abstract double computeSalary();
}
