package enums;

public enum Color {
	WHITE, SILVER, BLACK, BLUE, RED
}
