package p4;

@FunctionalInterface
public interface Computable {
	//public abstract : WHAT (specs)
	double anyOperation(double d1, double d2);
}
