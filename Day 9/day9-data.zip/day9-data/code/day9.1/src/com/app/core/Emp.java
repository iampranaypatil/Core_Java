package com.app.core;

public  class Emp {
	private double basic;

	public Emp(double basic) {
		super();
		this.basic = basic;
	}
	

	public double getBasic() {
		return basic;
	}


	public  double computeSalary()
	{
		return 100;
	}
}
