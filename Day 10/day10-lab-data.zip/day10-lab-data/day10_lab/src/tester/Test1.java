package tester;
import static utils.StudentCollectionUtils.populateList;

import java.util.List;

import com.app.core.Student;

public class Test1 {

	public static void main(String[] args) {
		// 1. Display all student details from a student list
		List<Student> studentList = populateList();
		System.out.println("Students : ");
		studentList.forEach(s -> System.out.println(s));
		
	}

}
