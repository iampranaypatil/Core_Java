package tester;
import static utils.StudentCollectionUtils.*;

import java.util.Map;

import com.app.core.Student;
public class Test2 {

	public static void main(String[] args) {
		Map<String, Student> studentMap = populateMap(populateList());
		studentMap.forEach((k,v) -> System.out.println(v));

	}

}
