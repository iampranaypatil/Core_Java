package method_overriding;

public class B extends A{
	@Override
	public void show() {
		System.out.println("2");
	}
}
