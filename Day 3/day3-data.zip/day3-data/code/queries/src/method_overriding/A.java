package method_overriding;

public class A {
	public void show() {
		System.out.println("1");
	}
}
