package method_overriding2;

public class A {
	public static void show() {
		System.out.println("1");
	}
}
