package method_overriding2;

public class B extends A{
//	@Override
	public static void show() {
		System.out.println("2");
	}
}
